/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.cuentas;

public class CuentaDeAhorros {
   
    
    public static void main(String[] args) {
        Cuenta cuenta1= new Cuenta(123,"maria",1000);
        Cuenta cuenta2= new Cuenta(1245,"maria",1000);   
    }
}
