/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.cuentas;

import java.util.Arrays;

/**
 *
 * @author jalvarez54
 */
public class Prueba {

    public static void main(String[] args) {
        int numero01 = 40;
        int numero02 = 150;
        int suma = Metodos.sumar(numero01, numero02);
        System.out.println("la suma es " + suma);

        double numero03 = 5.6;
        double numero04 = 10.8;
        double sumaReal=Metodos.sumar(numero03, numero04);
        System.out.println("la suma de numeros reales es"+sumaReal);
        
        int[] vector1={1,2,3,4,5};
        int[] vector2={2,4,6,8,10};
        int[] sumaVector= Metodos.sumar(vector1, vector2);
        System.out.println("la suma vectorial es"+Arrays.toString(sumaVector));
    }

}
