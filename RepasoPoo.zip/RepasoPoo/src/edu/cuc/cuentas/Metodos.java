
package edu.cuc.cuentas;


public class Metodos {
    public static  int sumar(int numero01,int numero02){
        return numero01+numero02;
        
    }
     public static  double sumar(double numero03,double numero04){
        return numero03+numero04;
  }
   public static  int[] sumar(int [] vector1,int [] vector2){
       if (vector1.length == vector2.length) {
          // suma de vectores 
          int [] suma= new int [vector1.length];
           for (int i = 0; i < suma.length; i++) {
              suma[i]=vector1[i]+vector2[i];
               
           }
           return suma;
       } else {
           // nose puede hacer la suma
           return null;
       }
       }
}