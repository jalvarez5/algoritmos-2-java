/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.figuras;

/**
 *
 * @author jalvarez54
 */
public class Prueba {
    public static void main(String[] args) {
        Rectangulo rectangulo1= new Rectangulo(3, 5);
        System.out.println(rectangulo1.getNumeroLados());
        System.out.println("area"+rectangulo1.calcularArea());
        System.out.println("perimetro"+rectangulo1.calcularPerimetro());
        
        Rectangulo rectangulo2= new Rectangulo(7, 9);
         System.out.println("perimetro"+rectangulo2.calcularPerimetro());
          System.out.println("area"+rectangulo2.calcularArea());
    }
    
}
