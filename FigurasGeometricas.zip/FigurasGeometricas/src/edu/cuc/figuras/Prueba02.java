/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.figuras;

/**
 *
 * @author jalvarez54
 */
public class Prueba02 {
    public static void main(String[] args) {
        Cuadrado cuadrado1=new Cuadrado(15);
        System.out.println(cuadrado1);
        System.out.println("Area"+cuadrado1.calcularArea());
        System.out.println("perimetro"+cuadrado1.calcularPerimetro());
    }
}
